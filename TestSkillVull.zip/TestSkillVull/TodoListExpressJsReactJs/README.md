# TodoListExpressJsReactJs
Fullstack To do list using ExpressJs and react js

di sini saya menggungganakan Express JS sebagai Backendnya

kemudian saya menggunakan React js untuk frontendnya
